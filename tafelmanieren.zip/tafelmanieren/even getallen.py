start, end = 20, 50
for num in range(start, end +2):
    if num % 2 == 0:
        print(num, end = " ")