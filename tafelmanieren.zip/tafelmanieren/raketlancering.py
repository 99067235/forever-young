import time

for i in range(31,0, -1):
    print(i - 1)
    time.sleep(1)
print("LANCEREN!!!")