for i in range(0,12, +1):
    print(i +1, "AM")
for i in range(0,12, +1):
    print(i +1, "PM")